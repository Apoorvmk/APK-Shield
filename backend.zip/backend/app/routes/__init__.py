"""Routes package for APK endpoints."""

from .upload_routes import router  # re-export for convenience
